package com.example.MedicalRepresentativeSchedule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class MedicalRepresentativeScheduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalRepresentativeScheduleApplication.class, args);
		System.out.println("Med Rep Service is Running");
	}

}
