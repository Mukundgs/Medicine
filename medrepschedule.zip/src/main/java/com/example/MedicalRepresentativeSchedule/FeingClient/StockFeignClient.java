package com.example.MedicalRepresentativeSchedule.FeingClient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(url="http://localhost:8789", name="stockMedicine")
public interface StockFeignClient 
{
	@GetMapping(value="/MedicineStockInformation/byTreatingAilment/{treatingAilment}")
		public List<String> getMedicineByTreatingAilment(@PathVariable("treatingAilment") String treatingAilment);
		
}
