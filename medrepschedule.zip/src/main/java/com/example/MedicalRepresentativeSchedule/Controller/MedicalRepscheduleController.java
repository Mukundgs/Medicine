package com.example.MedicalRepresentativeSchedule.Controller;

import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.MedicalRepresentativeSchedule.Service.RepScheduleService;

@CrossOrigin
@RestController
@RequestMapping("/RepSchedule")
public class MedicalRepscheduleController
{
	@Autowired
	private RepScheduleService service;
	
	@GetMapping("")
	public ResponseEntity<?> showSchedule(@RequestParam String startdate) throws ParseException
	{    
		
		System.out.println("The Date Is:"+startdate);
		String pharmacyname = null;
		System.out.println("i have arrved");
			return new ResponseEntity<>(service.returnschedule(startdate), HttpStatus.OK);
	}
	
}
