package com.example.MedicalRepresentativeSchedule.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.MedicalRepresentativeSchedule.Model.Doctor;

@Service
public class DoctorService 
{
	private static List<Doctor> doclist=new ArrayList<Doctor>();
	private static int docCount = 0;
	
	static
	{
		doclist.add(new Doctor("Umesh","9888477383","General","1PM to 2PM"));
		doclist.add(new Doctor("Lavanya","9885477381","Gynaecology","1PM to 2PM"));
		doclist.add(new Doctor("Rameshwar","9858427382","Orthopaedics","2PM to 3PM"));
		doclist.add(new Doctor("Yukthi","8668477381","Oncology","1PM to 2PM"));
		doclist.add(new Doctor("Raj","9088477381","General","2PM to 3PM"));
		docCount=5;
	}
	
	public Doctor retrieveDoc() {
        for (Doctor doc : doclist) {
            if(!doc.isAllotted()) {
                return doc;
            }
        }
        return null;
    }
	
	public Doctor retrieveDoc(String n) {
        for (Doctor doc : doclist) {
            if(!doc.isAllotted() && !doc.getName().equals(n)) {
                return doc;
            }
        }
        return null;
    }
	
	
	public void setAllotment(String n) {
		for (Doctor doc : doclist) {
            if(doc.getName().equals(n)) {
                doc.setAllotted(true);
                break;
            }
        }
	}
	

	public void resetAllotment() {
		for (Doctor doc : doclist) {
            doc.setAllotted(false);
        }
	}
	

	public List<Doctor> getDoclist() {
		return doclist;
	}
	

	public int getDocCount() {
		return docCount;
	}
	

	public void setDocCount(int docCount) {
		DoctorService.docCount = docCount;
	}
	 
	
}
