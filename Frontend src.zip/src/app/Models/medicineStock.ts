export class MedicineStock{
    id:number;
    name:string;
    chemicalComposition:string;
    targetAilment:string;
    dateofExpiry:Date;
    numberOfTabletsInStock:number;
}