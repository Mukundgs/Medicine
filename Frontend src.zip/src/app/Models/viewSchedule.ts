export class ViewSchedule{
    name: string;
    doc: string;
    ailment: string;
    meds: string;
    slot: string;
    date: Date;
    number: number;
}