export class MedicineDemand{
      id:number;
      medicinename:string;
      pharmacyname:string;
      supplycount:number;
}