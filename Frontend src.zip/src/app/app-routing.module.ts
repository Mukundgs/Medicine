import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MedicineStockComponent } from './medicine-stock/medicine-stock.component';
import { ViewScheduleComponent } from './view-schedule/view-schedule.component';
import { PlaceDemandComponent } from './place-demand/place-demand.component';
import { SignupComponent } from './signup/signup.component';
import { AuthGuard } from './auth.guard';


const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'home', component: HomeComponent },
   { path: 'ms', component: MedicineStockComponent,canActivate:[AuthGuard] },
   { path: 'pd', component: PlaceDemandComponent,canActivate:[AuthGuard] },
  { path: 'vs', component: ViewScheduleComponent,canActivate:[AuthGuard] },

  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
