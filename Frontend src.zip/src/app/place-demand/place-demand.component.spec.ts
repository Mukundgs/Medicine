import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceDemandComponent } from './place-demand.component';

describe('PlaceDemandComponent', () => {
  let component: PlaceDemandComponent;
  let fixture: ComponentFixture<PlaceDemandComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlaceDemandComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlaceDemandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
