import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MedicineDemand } from '../Models/medicineDemand';
import { MedicineDemandService } from '../Service/medicine-demand.service';

@Component({
  selector: 'app-place-demand',
  templateUrl: './place-demand.component.html',
  styleUrls: ['./place-demand.component.css']
})
export class PlaceDemandComponent {
   medicineDemand: MedicineDemand[]=[];
   show:number=0;
   data!: FormGroup;

   constructor(private medicineService:MedicineDemandService,
    private http: HttpClient,
    private formBuilder: FormBuilder){}

   ngOnInit():void{
    this.data = this.formBuilder.group({
      medicine: ['', Validators.required],
      demand: ['', Validators.required]
    })
     this.getMedicineDemand();
   }

   getMedicineDemand(){
    console.log(this.data.value)
    this.http.get<[]>("http://localhost:8788/PharmacyMedicineSupply?medicine="+this.data.value.medicine+"&demand="+this.data.value.demand)
    .subscribe((result) => {
      this.medicineDemand=result,
      console.log(this.medicineDemand)
      this.show = 1
    },)
   }

  
}
