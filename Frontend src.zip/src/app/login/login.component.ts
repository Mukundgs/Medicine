import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../Service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm!: FormGroup;
  // User: UserModel;



  constructor(private fb: FormBuilder,

    private router: Router, private auth: AuthService) { }



  ngOnInit(): void {

    this.loginForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    })

  }



  onLogin() {
    if (this.loginForm.valid) {
      if (this.loginForm.value.email === 'mukund.gowrishankar@ust.com' && this.loginForm.value.password === 'Asd@123'||
      this.loginForm.value.email === 'mukund2305@gmail.com' && this.loginForm.value.password === 'Asd@123') {
        alert("Logedin Successfully")
        localStorage.setItem('token','mukund')
        this.router.navigate(['/home'])

      }
      else{
        alert("Invalid Credentials")
      }
    }
    

  }



  private validateAllFormFields(formGroup: FormGroup) {

    Object.keys(formGroup.controls).forEach(field => {

      const control = formGroup.get(field);

      if (control instanceof FormControl) {

        control.markAsDirty({ onlySelf: true });

      } else if (control instanceof FormGroup) {

        this.validateAllFormFields(control)

      }

    })

  }




}