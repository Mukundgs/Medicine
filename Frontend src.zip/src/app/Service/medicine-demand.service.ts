import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MedicineDemand } from '../Models/medicineDemand';

@Injectable({
  providedIn: 'root'
})
export class MedicineDemandService {

  private url: string = "";

  constructor(private http: HttpClient) { }

  getMedicalDemand(){
    return this.http.get<MedicineDemand[]>(this.url)
  }
}
