import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ViewSchedule } from '../Models/viewSchedule';

@Injectable({
  providedIn: 'root'
})
export class ViewScheduleService {

  public startdate=new BehaviorSubject<string>("")
  private url: string = "http://localhost:8787/RepSchedule";
  constructor(private http: HttpClient) { }

  getViewSchedule() {
    return this.http.get<ViewSchedule[]>(this.url)
  }

  getViewSchedulebydate(){
    return this.http.get<ViewSchedule[]>("http://localhost:8787/RepSchedule?startdate="+this.startdate)
  }

}
