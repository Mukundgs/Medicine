export class MedicineStockService
{
    
    name: string;
    chemicalComposition: string;
    targetAilment: string;
    dateOfExpiry: Date;
    numberOfTabletsInStock: string;
}