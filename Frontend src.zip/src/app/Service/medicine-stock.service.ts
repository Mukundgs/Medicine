import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MedicineStock } from '../Models/medicineStock';

@Injectable({
  providedIn: 'root'
})

export class MedicineStockService {


  constructor(private http: HttpClient) { }

  getMedicalStock():Observable<any>{
    return this.http.get(`http://localhost:8789/MedicineStockInformation/getallmedicine`);
  }
}

