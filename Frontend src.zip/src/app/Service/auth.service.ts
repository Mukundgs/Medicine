import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private url: string = "https://localhost:3001/api/Users/";



  constructor(private http: HttpClient) { }

  signUp(userObj: any) {

    return this.http.post<any>(`${this.url}register`, userObj)

  }

  login(loginObj: any) {

    return this.http.post<any>(`${this.url}authenticate`, loginObj)

  }

  SignOut() {

    localStorage.clear();

  }

  isLoggedIn() {
    return !!localStorage.getItem('token');
  }
}
