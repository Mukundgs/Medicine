import { Component } from '@angular/core';
import { MedicineStock } from '../Models/medicineStock';
import { MedicineStockService } from '../Service/medicine-stock.service';

@Component({
  selector: 'app-medicine-stock',
  templateUrl: './medicine-stock.component.html',
  styleUrls: ['./medicine-stock.component.css']
})
export class MedicineStockComponent {

  medicineStock: MedicineStock[]=[];

  constructor(private medicineService:MedicineStockService){}

  ngOnInit(): void{
    this.getMedicineStock();
  }

  getMedicineStock(){
    this.medicineService.getMedicalStock().subscribe((result) => {
      this.medicineStock=result
    },)
  }

}
