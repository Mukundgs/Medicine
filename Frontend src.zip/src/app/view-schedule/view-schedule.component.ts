import { Component } from '@angular/core';
import { ViewScheduleService } from '../Service/view-schedule.service';
import { ViewSchedule } from '../Models/viewSchedule';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-schedule',
  templateUrl: './view-schedule.component.html',
  styleUrls: ['./view-schedule.component.css']
})
export class ViewScheduleComponent {
  viewSchedule: ViewSchedule[] = [];
  date!: FormGroup;
  show: number = 0;
  constructor(private formBuilder: FormBuilder,
    private http: HttpClient) { }

  ngOnInit(): void {
    this.date = this.formBuilder.group({
      startdate: ['', Validators.required]
    })
    this.getViewSchedule();
  }

  getViewSchedule() {
    this.http.get<ViewSchedule[]>("http://localhost:8787/RepSchedule?startdate=" + this.date.value.startdate)
      .subscribe((result) => {
        this.viewSchedule = result,
          console.log(this.viewSchedule)
        this.show = 1
      },)
  }


}
