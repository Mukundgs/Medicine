package com.example.medical_represent.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.medical_represent.Repo.RepresentativeRepo;
import com.example.medical_represent.model.Representative;

@Service
public class Reprensentimplement implements RepresentInterface
{	
	@Autowired
	private RepresentativeRepo repo;

	@Override
	public List<Representative> getallRepresent() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Representative addRepresent(Representative reps) {
		// TODO Auto-generated method stub
		return repo.save(reps);
	}

	@Override
	public void deleteRepresent(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}


}
