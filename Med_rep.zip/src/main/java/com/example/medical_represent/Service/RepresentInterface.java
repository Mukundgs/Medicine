package com.example.medical_represent.Service;

import java.util.List;

import com.example.medical_represent.model.Representative;



public interface RepresentInterface 
{
	public List<Representative> getallRepresent();
	public Representative addRepresent(Representative reps);
	public void deleteRepresent(int id);
}
