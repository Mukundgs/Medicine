package com.example.medical_represent.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.medical_represent.model.Representative;

@Repository
public interface RepresentativeRepo extends JpaRepository<Representative, Integer>
{

}
