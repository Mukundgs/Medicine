package com.example.medical_represent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalRepresentApplicationTests {

	@Test
	void contextLoads() {
	}

}
