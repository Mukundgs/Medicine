package com.example.MedicineStock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicineStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
