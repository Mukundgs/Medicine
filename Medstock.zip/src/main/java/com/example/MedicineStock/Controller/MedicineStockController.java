package com.example.MedicineStock.Controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.MedicineStock.Model.MedicineStock;
import com.example.MedicineStock.Service.MedicineStockInterface;

@CrossOrigin
@RestController
@RequestMapping("/MedicineStockInformation")
public class MedicineStockController 
{
	@Autowired
	private MedicineStockInterface MedInter;
	
	@PostMapping("/create")
    public ResponseEntity<MedicineStock> addMedicineStock(@RequestBody MedicineStock medstock){
        MedicineStock saved=MedInter.addMedicineStock(medstock);
        return new ResponseEntity<>(saved,HttpStatus.CREATED);
    }

    @GetMapping("/getallmedicine")
   public ResponseEntity<List<MedicineStock>> getallMedicineStock(){
      List<MedicineStock> getall=MedInter.getallMedicineStock();
       return new ResponseEntity<>(getall,HttpStatus.OK);
   }
    @GetMapping("/getstockcount/{medicine}")
	public ResponseEntity<?>getNumberOfTabletsInStockByName(@PathVariable("medicine") String medicine) {
	
		return new ResponseEntity<>(MedInter.getNumberOfTabletsInStockByName(medicine), HttpStatus.OK);

    }    
    
    @GetMapping("/byTreatingAilment/{treatingAilment}")
    public ResponseEntity<?> getMedicineByTreatingAilment(@PathVariable("treatingAilment") String treatingAilment) 
    {
		List<String> medicines = new ArrayList<>();
		List<MedicineStock> medicineByTargetAilment = MedInter.getMedicineByTargetAilment(treatingAilment);		
		for (Iterator iterator = medicineByTargetAilment.iterator(); iterator.hasNext();) 
		{
			MedicineStock medicineStock = (MedicineStock) iterator.next();
			medicines.add(medicineStock.getName());
		}
		return new ResponseEntity<>(medicines.toArray(new String[0]), HttpStatus.OK);
	}
    
    @DeleteMapping("/deletemed/{id}")
   public ResponseEntity<String> deleteMedicineStock(@PathVariable("id") int id){
      MedInter.deleteMedicineStock(id);
      return new ResponseEntity<>("Deleted from the Medicine Database!",HttpStatus.OK);
   }
    

}
