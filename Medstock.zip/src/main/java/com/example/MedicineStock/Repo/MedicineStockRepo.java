package com.example.MedicineStock.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.MedicineStock.Model.MedicineStock;

import jakarta.websocket.server.PathParam;

@Repository
public interface MedicineStockRepo extends JpaRepository<MedicineStock,String> 
{
	@Query(name = "select * from medicine where target_ailment = :targetAilment", nativeQuery = true)
	List<MedicineStock> getMedicineByTargetAilment(@PathParam("targetAilment") String targetAilment);

	
	@Query(name = "SELECT number_of_tablets_in_stock FROM medicine_stock where name = :medicine", nativeQuery = true)
	MedicineStock getNumberOfTabletsInStockByName(@PathParam("medicine") String medicine);
}
