package com.example.MedicineStock.Service;

import java.util.List;

import com.example.MedicineStock.Model.MedicineStock;

public interface MedicineStockInterface 
{
		public List<MedicineStock> getallMedicineStock();

		public MedicineStock addMedicineStock(MedicineStock medicine);

		public void deleteMedicineStock(int id);

		public int getNumberOfTabletsInStockByName(String medicine);
		
		List<MedicineStock> getMedicineByTargetAilment(String treatingAilment);

}

