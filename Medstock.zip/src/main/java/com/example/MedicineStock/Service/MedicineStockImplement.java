package com.example.MedicineStock.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MedicineStock.Model.MedicineStock;
import com.example.MedicineStock.Repo.MedicineStockRepo;


@Service
public class MedicineStockImplement implements MedicineStockInterface
{	
	@Autowired
	private MedicineStockRepo repo;
	@Override
	public List<MedicineStock> getallMedicineStock() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	/*
	 * @Override public MedicineStock addMedicineStock(MedicineStock medstock) { //
	 * TODO Auto-generated method stub return repo.save(medstock); }
	 * 
	 * @Override public void deleteMedicineStock(int id) { // TODO Auto-generated
	 * method stub repo.deleteById(id);
	 * 
	 * }
	 */
	
	public int getNumberOfTabletsInStockByName(String medicine)
	{
		return repo.getNumberOfTabletsInStockByName(medicine).getNumberOfTabletsInStock();
	}

	@Override
	public List<MedicineStock> getMedicineByTargetAilment(String treatingAilment)
	{
		return repo.getMedicineByTargetAilment(treatingAilment);
	}
	
	@Override
	public MedicineStock addMedicineStock(MedicineStock medicine) {
		// TODO Auto-generated method stub
		return repo.save(medicine);
	}

	@Override
	public void deleteMedicineStock(int id) 
	{
		// TODO Auto-generated method stub
		
	}
}
