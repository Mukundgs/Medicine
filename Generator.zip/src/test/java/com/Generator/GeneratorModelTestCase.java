import org.junit.Test;
import org.junit.Assert;

public class GeneratorModelTestCase {

@Test
public void testcom.Generator.model.GeneratorModel() {
    // Arrange
    // Act
    GeneratorModel instance = new GeneratorModel(/* constructor parameters */);
    // Assert
    Assert.assertNotNull(instance);
}

@Test
public void testcom.Generator.model.GeneratorModel() {
    // Arrange
    // Act
    GeneratorModel instance = new GeneratorModel(/* constructor parameters */);
    // Assert
    Assert.assertNotNull(instance);
}

@Test
public void testid() {
    // Arrange
    // Act
    // Assert
}

@Test
public void testname() {
    // Arrange
    // Act
    // Assert
}

@Test
public void testsetId() {
    // Arrange
    // Act
    // Assert
}

@Test
public void testgetName() {
    // Arrange
    // Act
    // Assert
}

@Test
public void testsetName() {
    // Arrange
    // Act
    // Assert
}

@Test
public void testgetId() {
    // Arrange
    // Act
    // Assert
}

}
