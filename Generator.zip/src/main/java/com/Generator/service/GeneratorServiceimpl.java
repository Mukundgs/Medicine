package com.Generator.service;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class GeneratorServiceimpl<T> implements GeneratorService<T> {
    private final Map<Long, T> entities = new HashMap<>();
    private final Class<T> entityClass;

    public GeneratorServiceimpl(Class<T> entityClass) {
        this.entityClass = entityClass;
    }

    @Override
    public T create(T entity) {
        try {
            Field idField = entityClass.getDeclaredField("id");
            idField.setAccessible(true);
            Long id = (Long) idField.get(entity);
            entities.put(id, entity);
            return entity;
        } catch (Exception e) {
            throw new RuntimeException("Error creating entity: " + e.getMessage());
        }
    }

    @Override
    public T read(Long id) {
        return entities.get(id);
    }

    @Override
    public T update(T entity) {
        try {
            Field idField = entityClass.getDeclaredField("id");
            idField.setAccessible(true);
            Long id = (Long) idField.get(entity);
            entities.put(id, entity);
            return entity;
        } catch (Exception e) {
            throw new RuntimeException("Error updating entity: " + e.getMessage());
        }
    }

    @Override
    public void delete(Long id) {
        entities.remove(id);
    }

    @Override
    public List<T> getAll() {
        return new ArrayList<>(entities.values());
    }
    
}
