package com.Generator.service;

import java.util.List;

public interface GeneratorService<T> {
    T create(T entity);
    T read(Long id);
    T update(T entity);
    void delete(Long id);
    List<T> getAll();
}

