package com.Generator;

import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
	public class GeneratorApplication 
	{

	public static void main(String[] args) {
        Generation generation = new Generation();
        generation.generateTestCases("com.Generator");
    }
}


//	public static void main(String[] args)
//	{
//		String outputFile = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Unittesting.txt"; // Specify the output file path
//		List<String> classNames = extractClassNames(outputFile);
//		for (String className : classNames) {
//		try {
//		Class<?> targetClass = Class.forName(className);
//		generateTestCases(targetClass);
//		} catch (ClassNotFoundException e) {
//		e.printStackTrace();
//		}
//		}
//		}
//		private static List<String> extractClassNames(String outputFile) {
//		List<String> classNames = new ArrayList<>();
//		try (BufferedReader reader = new BufferedReader(new FileReader(outputFile))) {
//		String line;
//		while ((line = reader.readLine()) != null) {
//		if (line.startsWith("Class: ")) {
//		classNames.add(line.substring(7));
//		}
//		}
//		} catch (IOException e) {
//		e.printStackTrace();
//		}
//		return classNames;
//		}
//		private static void generateTestCases(Class<?> targetClass) {
//		// Generate test cases for constructors
//		Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
//		for (Constructor<?> constructor : constructors) {
//		generateConstructorTestCase(constructor);
//		}
//		// Generate test cases for methods
//		Method[] methods = targetClass.getDeclaredMethods();
//		for (Method method : methods) {
//		generateMethodTestCase(method);
//		}
//		}
//		private static void generateConstructorTestCase(Constructor<?> constructor) {
//		String constructorName = constructor.getName();
//		// Get the constructor's parameters
//		Parameter[] parameters = constructor.getParameters();
//		int parameterCount = parameters.length;
//		// Generate the test case method signature
//		System.out.println("public void test_" + constructorName + "() {");
//		// Generate the test case code
//		System.out.println("\t// Create test objects for the constructor's parameters");
//		for (int i = 0; i < parameterCount; i++) {
//		Parameter parameter = parameters[i];
//		String parameterType = parameter.getType().getSimpleName();
//		String parameterName = parameter.getName();
//		System.out.println("\t" + parameterType + " " + parameterName + " = createTest" + parameterType + "();");
//		}
//		// Generate the constructor invocation
//		StringBuilder constructorInvocation = new StringBuilder();
//		constructorInvocation.append("\t").append(constructor.getDeclaringClass().getSimpleName()).append(" instance = new ")
//		.append(constructor.getDeclaringClass().getSimpleName()).append("(");
//		for (int i = 0; i < parameterCount; i++) {
//		constructorInvocation.append(parameters[i].getName());
//		if (i < parameterCount - 1) {
//		constructorInvocation.append(", ");
//		}
//		}
//		constructorInvocation.append(");");
//		System.out.println(constructorInvocation.toString());
//		// Add assertions or further test logic
//		System.out.println("\t// Add assertions or further test logic");
//		// Close the test case method
//		System.out.println("}");
//		}
//		private static void generateMethodTestCase(Method method) {
//		String methodName = method.getName();
//		// Get the method's return type
//		Class<?> returnType = method.getReturnType();
//		// Get the method's parameters
//		Parameter[] parameters = method.getParameters();
//		int parameterCount = parameters.length;
//		// Generate the test case method signature
//		System.out.println("public void test_" + methodName + "() {");
//		// Generate the test case code
//		System.out.println("\t// Create test objects for the method's parameters");
//		for (int i = 0; i < parameterCount; i++) {
//		Parameter parameter = parameters[i];
//		String parameterType = parameter.getType().getSimpleName();
//		String parameterName = parameter.getName();
//		System.out.println("\t" + parameterType + " " + parameterName + " = createTest" + parameterType + "();");
//		}
//		// Generate the method invocation
//		StringBuilder methodInvocation = new StringBuilder();
//		if (!returnType.equals(void.class)) {
//		methodInvocation.append("\t").append(returnType.getSimpleName()).append(" result = ");
//		}
//		methodInvocation.append("instance.").append(methodName).append("(");
//		for (int i = 0; i < parameterCount; i++) {
//		methodInvocation.append(parameters[i].getName());
//		if (i < parameterCount - 1) {
//		methodInvocation.append(", ");
//		}
//		}
//		methodInvocation.append(");");
//		System.out.println(methodInvocation.toString());
//		// Add assertions or further test logic
//		System.out.println("\t// Add assertions or further test logic");
//		// Close the test case method
//		System.out.println("}");
//		}
//}
//		 private static final String OUTPUT_DIRECTORY = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Output"; // Specify the output directory
//
//		    public static void main(String[] args) {
//		        String inputFile = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Unittesting.txt"; // Specify the input file path
//		        List<String> classNames = extractClassNames(inputFile);
//		        for (String className : classNames) {
//		            try {
//		                Class<?> targetClass = Class.forName(className);
//		                generateTestCases(targetClass);
//		            } catch (ClassNotFoundException e) {
//		                e.printStackTrace();
//		            }
//		        }
//		    }
//
//		    private static List<String> extractClassNames(String inputFile) {
//		        List<String> classNames = new ArrayList<>();
//		        try (Scanner scanner = new Scanner(new File(inputFile))) {
//		            while (scanner.hasNextLine()) {
//		                String line = scanner.nextLine();
//		                if (line.startsWith("Class: ")) {
//		                    classNames.add(line.substring(7));
//		                }
//		            }
//		        } catch (FileNotFoundException e) {
//		            e.printStackTrace();
//		        }
//		        return classNames;
//		    }
//
//		    private static void generateTestCases(Class<?> targetClass) {
//		        StringBuilder testCaseBuilder = new StringBuilder();
//		        testCaseBuilder.append("import org.junit.Test;\n\n");
//		        testCaseBuilder.append("public class TestCase {\n\n");
//
//		        // Generate test cases for constructors
//		        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
//		        for (Constructor<?> constructor : constructors) {
//		            generateConstructorTestCase(testCaseBuilder, constructor);
//		        }
//
//		        // Generate test cases for methods
//		        Method[] methods = targetClass.getDeclaredMethods();
//		        for (Method method : methods) {
//		            generateMethodTestCase(testCaseBuilder, method);
//		        }
//
//		        testCaseBuilder.append("}\n");
//
//		        // Save the test case file
//		        String outputFilePath = OUTPUT_DIRECTORY + File.separator + targetClass.getSimpleName() + "TestCase.java";
//		        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
//		            writer.write(testCaseBuilder.toString());
//		        } catch (IOException e) {
//		            e.printStackTrace();
//		        }
//		    }
//
//		    private static void generateConstructorTestCase(StringBuilder testCaseBuilder, Constructor<?> constructor) {
//		        // Test case method signature
//		        String constructorName = constructor.getName();
//		        testCaseBuilder.append("\t@Test\n");
//		        testCaseBuilder.append("\tpublic void test_").append(constructorName).append("() {\n");
//
//		        // Generate the test case code
//		        // ...
//
//		        // Close the test case method
//		        testCaseBuilder.append("\t}\n\n");
//		    }
//
//		    private static void generateMethodTestCase(StringBuilder testCaseBuilder, Method method) {
//		        // Test case method signature
//		        String methodName = method.getName();
//		        testCaseBuilder.append("\t@Test\n");
//		        testCaseBuilder.append("\tpublic void test_").append(methodName).append("() {\n");
//
//		        // Generate the test case code
//		        // ...
//
//		        // Close the test case method
//		        testCaseBuilder.append("\t}\n\n");
//		    }
//		}

//	    private static final String OUTPUT_DIRECTORY = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Output"; // Specify the output directory
//
//	    public static void main(String[] args) {
//	        String basePackage = "com.Generator"; // Replace with the base package of your project
//	        String outputFile = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Unittesting.txt"; // Specify the output file path
//	        scanAndGenerateTestCases(basePackage, outputFile);
//	    }
//
//	    private static void scanAndGenerateTestCases(String basePackage, String outputFile) {
//	        try {
//	            Reflections reflections = new Reflections(basePackage, new SubTypesScanner(false));
//	            Set<Class<?>> classes = reflections.getSubTypesOf(Object.class);
//
//	            FileOutputStream fos = new FileOutputStream(outputFile);
//	            PrintStream ps = new PrintStream(fos);
//
//	            // Redirect the output to the file
//	            System.setOut(ps);
//
//	            for (Class<?> targetClass : classes) {
//	                generateTestCases(targetClass);
//	            }
//
//	            // Close the streams
//	            ps.close();
//	            fos.close();
//
//	            // Reset the output stream to console
//	            System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
//	        } catch (IOException e) {
//	            e.printStackTrace();
//	        }
//	    }
//
//	    private static void generateTestCases(Class<?> targetClass) {
//	        StringBuilder testCaseBuilder = new StringBuilder();
//	        testCaseBuilder.append("import org.junit.Test;\n\n");
//	        testCaseBuilder.append("public class ").append(targetClass.getSimpleName()).append("TestCase {\n\n");
//
//	        // Generate test cases for constructors
//	        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
//	        for (Constructor<?> constructor : constructors) {
//	            generateConstructorTestCase(testCaseBuilder, constructor);
//	        }
//
//	        // Generate test cases for methods
//	        Method[] methods = targetClass.getDeclaredMethods();
//	        for (Method method : methods) {
//	            generateMethodTestCase(testCaseBuilder, method);
//	        }
//
//	        testCaseBuilder.append("}\n");
//
//	        // Save the test case file
//	        String outputFilePath = OUTPUT_DIRECTORY + File.separator + targetClass.getSimpleName() + "TestCase.java";
//	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
//	            writer.write(testCaseBuilder.toString());
//	        } catch (IOException e) {
//	            e.printStackTrace();
//	        }
//	    }
//
//	    private static void generateConstructorTestCase(StringBuilder testCaseBuilder, Constructor<?> constructor) {
//	        // Test case method signature
//	        String constructorName = constructor.getName();
//	        testCaseBuilder.append("\t@Test\n");
//	        testCaseBuilder.append("\tpublic void test_").append(constructorName).append("() {\n");
//
//	        // Generate the test case code
//	        // ...
//
//	        // Close the test case method
//	        testCaseBuilder.append("\t}\n\n");
//	    }
//
//	    private static void generateMethodTestCase(StringBuilder testCaseBuilder, Method method) {
//	        // Test case method signature
//	        String methodName = method.getName();
//	        testCaseBuilder.append("\t@Test\n");
//	        testCaseBuilder.append("\tpublic void test_").append(methodName).append("() {\n");
//
//	        // Generate the test case code
//	        // ...
//
//	        // Close the test case method
//	        testCaseBuilder.append("\t}\n\n");
//	    }
//	}

//	    private static final String REFLECTIONS_OUTPUT_FILE = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Unittesting.txt"; // Specify the reflections output file path
//	    private static final String OUTPUT_DIRECTORY = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Output"; // Specify the output directory
//
//	    public static void main(String[] args) {
//	        String basePackage = "com.Generator"; // Replace with the base package of your project
//	        String reflectionsOutputFile = REFLECTIONS_OUTPUT_FILE;
//	        scanAndSaveReflectionsData(basePackage, reflectionsOutputFile);
//	        generateTestCasesFromReflectionsData(reflectionsOutputFile);
//	    }
//
//	    private static void scanAndSaveReflectionsData(String basePackage, String outputFile) {
//	        try {
//	            Reflections reflections = new Reflections(basePackage, new SubTypesScanner(false));
//	            Set<Class<?>> classes = reflections.getSubTypesOf(Object.class);
//
//	            FileOutputStream fos = new FileOutputStream(outputFile);
//	            PrintStream ps = new PrintStream(fos);
//
//	            // Redirect the output to the file
//	            System.setOut(ps);
//
//	            for (Class<?> targetClass : classes) {
//	                generateReflectionsData(targetClass);
//	            }
//
//	            // Close the streams
//	            ps.close();
//	            fos.close();
//
//	            // Reset the output stream to console
//	            System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
//	        } catch (IOException e) {
//	            e.printStackTrace();
//	        }
//	    }
//
//	    private static void generateReflectionsData(Class<?> targetClass) {
//	        // Print class name
//	        System.out.println("Class: " + targetClass.getName());
//
//	        // Print array information
//	        if (targetClass.isArray()) {
//	            Class<?> componentType = targetClass.getComponentType();
//	            System.out.println("Array Component Type: " + componentType.getName());
//	        }
//
//	        // Print constructors
//	        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
//	        System.out.println("Constructors:");
//	        for (Constructor<?> constructor : constructors) {
//	            System.out.println(constructor);
//	        }
//
//	        // Print fields
//	        Field[] fields = targetClass.getDeclaredFields();
//	        System.out.println("Fields:");
//	        for (Field field : fields) {
//	            System.out.println(field);
//	        }
//
//	        // Print methods
//	        Method[] methods = targetClass.getDeclaredMethods();
//	        System.out.println("Methods:");
//	        for (Method method : methods) {
//	            System.out.println(method);
//	        }
//
//	        System.out.println("_______________________");
//	    }
//
//	    private static void generateTestCasesFromReflectionsData(String reflectionsOutputFile) {
//	        try {
//	            File file = new File(reflectionsOutputFile);
//	            Scanner scanner = new Scanner(file);
//
//	            while (scanner.hasNextLine()) {
//	                String line = scanner.nextLine();
//	                if (line.startsWith("Class: ")) {
//	                    String className = line.substring(7);
//	                    Class<?> targetClass = Class.forName(className);
//	                    generateTestCases(targetClass);
//	                }
//	            }
//
//	            scanner.close();
//	        } catch (IOException | ClassNotFoundException e) {
//	            e.printStackTrace();
//	        }
//	    }
//
//	    private static void generateTestCases(Class<?> targetClass) {
//	        StringBuilder testCaseBuilder = new StringBuilder();
//	        testCaseBuilder.append("import org.junit.Test;\n\n");
//	        testCaseBuilder.append("public class ").append(targetClass.getSimpleName()).append("TestCase {\n\n");
//
//	        // ... Generate test cases as before ...
//
//	        testCaseBuilder.append("}\n");
//
//	        // Save the test case file
//	        String outputFilePath = OUTPUT_DIRECTORY + File.separator + targetClass.getSimpleName() + "TestCase.java";
//	        try (PrintWriter writer = new PrintWriter(outputFilePath)) {
//	            writer.write(testCaseBuilder.toString());
//	        } catch (FileNotFoundException e) {
//	            e.printStackTrace();
//	        }
//	    }
//	}
//    private static final String REFLECTIONS_OUTPUT_FILE = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Unittesting.txt";
//    private static final String OUTPUT_DIRECTORY = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Output";
//
//    public static void main(String[] args) {
//        String basePackage = "com.Generator";
//        String reflectionsOutputFile = REFLECTIONS_OUTPUT_FILE;
//        scanAndSaveReflectionsData(basePackage, reflectionsOutputFile);
//        generateTestCasesFromReflectionsData(reflectionsOutputFile);
//    }
//
//    private static void scanAndSaveReflectionsData(String basePackage, String outputFile) {
//        try {
//            Reflections reflections = new Reflections(basePackage, new SubTypesScanner(false));
//            Set<Class<?>> classes = reflections.getSubTypesOf(Object.class);
//
//            FileOutputStream fos = new FileOutputStream(outputFile);
//            PrintStream ps = new PrintStream(fos);
//
//            // Redirect the output to the file
//            System.setOut(ps);
//
//            for (Class<?> targetClass : classes) {
//                generateReflectionsData(targetClass);
//            }
//
//            // Close the streams
//            ps.close();
//            fos.close();
//
//            // Reset the output stream to console
//            System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private static void generateReflectionsData(Class<?> targetClass) {
//        // Print class name
//        System.out.println("Class: " + targetClass.getName());
//
//        // Print array information
//        if (targetClass.isArray()) {
//            Class<?> componentType = targetClass.getComponentType();
//            System.out.println("Array Component Type: " + componentType.getName());
//        }
//
//        // Print constructors
//        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
//        System.out.println("Constructors:");
//        for (Constructor<?> constructor : constructors) {
//            System.out.println(constructor);
//        }
//
//        // Print fields
//        Field[] fields = targetClass.getDeclaredFields();
//        System.out.println("Fields:");
//        for (Field field : fields) {
//            System.out.println(field);
//        }
//
//        // Print methods
//        Method[] methods = targetClass.getDeclaredMethods();
//        System.out.println("Methods:");
//        for (Method method : methods) {
//            System.out.println(method);
//        }
//
//        System.out.println("_______________________");
//    }
//
//    private static void generateTestCasesFromReflectionsData(String reflectionsOutputFile) {
//        try {
//            File file = new File(reflectionsOutputFile);
//            Scanner scanner = new Scanner(file);
//
//            while (scanner.hasNextLine()) {
//                String line = scanner.nextLine();
//                if (line.startsWith("Class: ")) {
//                    String className = line.substring(7);
//                    Class<?> targetClass = Class.forName(className);
//                    generateTestCases(targetClass);
//                }
//            }
//
//            scanner.close();
//        } catch (IOException | ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private static void generateTestCases(Class<?> targetClass) {
//        StringBuilder testCaseBuilder = new StringBuilder();
//        testCaseBuilder.append("import org.junit.Test;\n");
//        testCaseBuilder.append("import org.junit.Assert;\n\n");
//        testCaseBuilder.append("public class ").append(targetClass.getSimpleName()).append("TestCase {\n\n");
//
//        // Get constructors, fields, and methods for the target class
//        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
//        Field[] fields = targetClass.getDeclaredFields();
//        Method[] methods = targetClass.getDeclaredMethods();
//
//        // Generate test case for each constructor
//        for (Constructor<?> constructor : constructors) {
//            testCaseBuilder.append("@Test\n");
//            testCaseBuilder.append("public void test").append(constructor.getName()).append("() {\n");
//            testCaseBuilder.append("    // Arrange\n");
//            // Add necessary code to set up constructor parameters if applicable
//
//            testCaseBuilder.append("    // Act\n");
//            testCaseBuilder.append("    ").append(targetClass.getSimpleName()).append(" instance = new ").append(targetClass.getSimpleName()).append("(/* constructor parameters */);\n");
//
//            testCaseBuilder.append("    // Assert\n");
//            testCaseBuilder.append("    Assert.assertNotNull(instance);\n");
//            testCaseBuilder.append("}\n\n");
//        }
//
//        // Generate test case for each field
//        for (Field field : fields) {
//            testCaseBuilder.append("@Test\n");
//            testCaseBuilder.append("public void test").append(field.getName()).append("() {\n");
//            testCaseBuilder.append("    // Arrange\n");
//            // Add necessary code to set up object instance and field value if applicable
//
//            testCaseBuilder.append("    // Act\n");
//            // Add necessary code to access or modify the field
//
//            testCaseBuilder.append("    // Assert\n");
//            // Add necessary assertions to verify the field's value or behavior
//
//            testCaseBuilder.append("}\n\n");
//        }
//
//        // Generate test case for each method
//        for (Method method : methods) {
//            testCaseBuilder.append("@Test\n");
//            testCaseBuilder.append("public void test").append(method.getName()).append("() {\n");
//            testCaseBuilder.append("    // Arrange\n");
//            // Add necessary code to set up object instance and method parameters if applicable
//
//            testCaseBuilder.append("    // Act\n");
//            // Add necessary code to invoke the method being tested
//
//            testCaseBuilder.append("    // Assert\n");
//            // Add necessary assertions to verify the method's return value or behavior
//
//            testCaseBuilder.append("}\n\n");
//        }
//
//        testCaseBuilder.append("}\n");
//
//        // Save the test case file
//        String outputFilePath = OUTPUT_DIRECTORY + File.separator + targetClass.getSimpleName() + "TestCase.java";
//        try (PrintWriter writer = new PrintWriter(outputFilePath)) {
//            writer.write(testCaseBuilder.toString());
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
//}
