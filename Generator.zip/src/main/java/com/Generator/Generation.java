package com.Generator;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Scanner;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;

@RunWith(MockitoJUnitRunner.class)
public class Generation {

//    private static final String REFLECTIONS_OUTPUT_FILE = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Unittesting.txt";
//    private static final String OUTPUT_DIRECTORY = "C:\\Users\\238783\\Documents\\STS work space\\Generator\\src\\test\\java\\com\\Generator";
//
//    public void generateTestCases(String basePackage) {
//        String reflectionsOutputFile = REFLECTIONS_OUTPUT_FILE;
//        scanAndSaveReflectionsData(basePackage, reflectionsOutputFile);
//        generateTestCasesFromReflectionsData(reflectionsOutputFile);
//    }
//
//    private void scanAndSaveReflectionsData(String basePackage, String outputFile) {
//        try {
//            Reflections reflections = new Reflections(basePackage, new SubTypesScanner(false));
//            Set<Class<?>> classes = reflections.getSubTypesOf(Object.class);
//
//            FileOutputStream fos = new FileOutputStream(outputFile);
//            PrintStream ps = new PrintStream(fos);
//
//            // Redirect the output to the file
//            System.setOut(ps);
//
//            for (Class<?> targetClass : classes) {
//                generateReflectionsData(targetClass);
//            }
//
//            // Close the streams
//            ps.close();
//            fos.close();
//
//            // Reset the output stream to console
//            System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private void generateReflectionsData(Class<?> targetClass) {
//        // Print class name
//        System.out.println("Class: " + targetClass.getName()); 
//
//        // Print array information
//        if (targetClass.isArray()) {
//            Class<?> componentType = targetClass.getComponentType();
//            System.out.println("Array Component Type: " + componentType.getName());
//        }
//
//        // Print constructors
//        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
//        System.out.println("Constructors:");
//        for (Constructor<?> constructor : constructors) {
//            System.out.println(constructor);
//        }
//
//        // Print fields
//        Field[] fields = targetClass.getDeclaredFields();
//        System.out.println("Fields:");
//        for (Field field : fields) {
//            System.out.println(field);
//        }
//
//        // Print methods
//        Method[] methods = targetClass.getDeclaredMethods();
//        System.out.println("Methods:");
//        for (Method method : methods) {
//            System.out.println(method);
//        }
//
//        System.out.println("_______________________");
//    }
//
//    private void generateTestCasesFromReflectionsData(String reflectionsOutputFile) {
//        try {
//            File file = new File(reflectionsOutputFile);
//            Scanner scanner = new Scanner(file);
//
//            while (scanner.hasNextLine()) {
//                String line = scanner.nextLine();
//                if (line.startsWith("Class: ")) {
//                    String className = line.substring(7);
//                    Class<?> targetClass = Class.forName(className);
//                    generateTestCases(targetClass);
//                }
//            }
//
//            scanner.close();
//        } catch (IOException | ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private void generateTestCases(Class<?> targetClass) {
//        StringBuilder testCaseBuilder = new StringBuilder();
//        testCaseBuilder.append("import org.junit.Test;\n");
//        testCaseBuilder.append("import org.junit.Assert;\n\n");
//        testCaseBuilder.append("public class ").append(targetClass.getSimpleName()).append("TestCase {\n\n");
//
//        // Get constructors, fields, and methods for the target class
//        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
//        Field[] fields = targetClass.getDeclaredFields();
//        Method[] methods = targetClass.getDeclaredMethods();
//
//        // Generating test case for each constructor
//        for (Constructor<?> constructor : constructors) {
//            testCaseBuilder.append("@Test\n");
//            testCaseBuilder.append("public void test").append(constructor.getName()).append("() {\n");
//            testCaseBuilder.append("    // Arrange\n");
//            testCaseBuilder.append("    // Act\n");
//            testCaseBuilder.append("    ").append(targetClass.getSimpleName()).append(" instance = new ").append(targetClass.getSimpleName()).append("(/* constructor parameters */);\n");
//            testCaseBuilder.append("    // Assert\n");
//            testCaseBuilder.append("    Assert.assertNotNull(instance);\n");
//            testCaseBuilder.append("}\n\n");
//        }
//
//        // Generating test case for each field
//        for (Field field : fields) {
//            testCaseBuilder.append("@Test\n"); 
//            testCaseBuilder.append("public void test").append(field.getName()).append("() {\n");
//            testCaseBuilder.append("    // Arrange\n");
//            testCaseBuilder.append("    // Act\n");
//            testCaseBuilder.append("    ").append(targetClass.getSimpleName()).append(" instance = new ").append(targetClass.getSimpleName()).append("(/* constructor parameters */);\n");
//            testCaseBuilder.append("    // Assert\n");
//            testCaseBuilder.append("}\n\n");
//        }
//
//        // Generate test case for each method
//        for (Method method : methods) {
//            testCaseBuilder.append("@Test\n");
//            testCaseBuilder.append("public void test").append(method.getName()).append("() {\n");
//            testCaseBuilder.append("    // Arrange\n");
//            testCaseBuilder.append("    // Act\n");
//            testCaseBuilder.append("    ").append(targetClass.getSimpleName()).append(" instance = new ").append(targetClass.getSimpleName()).append("(/* constructor parameters */);\n");
//            testCaseBuilder.append("    // Assert\n");
//            testCaseBuilder.append("}\n\n");
//        }
//
//        testCaseBuilder.append("}\n");
//
//        // Save the test case file
//        String outputFilePath = OUTPUT_DIRECTORY + File.separator + targetClass.getSimpleName() + "TestCase.java";
//        try (PrintWriter writer = new PrintWriter(outputFilePath)) {
//            writer.write(testCaseBuilder.toString());
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
	  private static final String REFLECTIONS_OUTPUT_FILE = "C:\\Users\\238783\\Documents\\workspace-spring-tool-suite-4-4.16.1.RELEASE\\Unittesting.txt";
	    private static final String OUTPUT_DIRECTORY = "C:\\Users\\238783\\Documents\\STS work space\\Generator\\src\\test\\java\\com\\Generator";

	    @Mock
	    private Object instance;

	    @Test
	    public void generateTestCases() {
	        String basePackage = "your.base.package";
	        String reflectionsOutputFile = REFLECTIONS_OUTPUT_FILE;
	        scanAndSaveReflectionsData(basePackage, reflectionsOutputFile);
	        generateTestCasesFromReflectionsData(reflectionsOutputFile);
	    }

	    private void scanAndSaveReflectionsData(String basePackage, String outputFile) {
	        try {
	            Reflections reflections = new Reflections(basePackage, new SubTypesScanner(false));
	            Set<Class<?>> classes = reflections.getSubTypesOf(Object.class);

	            FileOutputStream fos = new FileOutputStream(outputFile);
	            PrintStream ps = new PrintStream(fos);

	            // Redirect the output to the file
	            System.setOut(ps);

	            for (Class<?> targetClass : classes) {
	                generateReflectionsData(targetClass);
	            }

	            // Close the streams
	            ps.close();
	            fos.close();

	            // Reset the output stream to console
	            System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    private void generateReflectionsData(Class<?> targetClass) {
	        // Print class name
	        System.out.println("Class: " + targetClass.getName());

	        // Print array information
	        if (targetClass.isArray()) {
	            Class<?> componentType = targetClass.getComponentType();
	            System.out.println("Array Component Type: " + componentType.getName());
	        }

	        // Print constructors
	        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
	        System.out.println("Constructors:");
	        for (Constructor<?> constructor : constructors) {
	            System.out.println(constructor);
	        }

	        // Print fields
	        Field[] fields = targetClass.getDeclaredFields();
	        System.out.println("Fields:");
	        for (Field field : fields) {
	            System.out.println(field);
	        }

	        // Print methods
	        Method[] methods = targetClass.getDeclaredMethods();
	        System.out.println("Methods:");
	        for (Method method : methods) {
	            System.out.println(method);
	        }

	        System.out.println("_______________________");
	    }

	    private void generateTestCasesFromReflectionsData(String reflectionsOutputFile) {
	        try {
	            File file = new File(reflectionsOutputFile);
	            Scanner scanner = new Scanner(file);

	            while (scanner.hasNextLine()) {
	                String line = scanner.nextLine();
	                if (line.startsWith("Class: ")) {
	                    String className = line.substring(7);
	                    Class<?> targetClass = Class.forName(className);
	                    generateTestCases(targetClass);
	                }
	            }

	            scanner.close();
	        } catch (IOException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	    }

	    private void generateTestCases(Class<?> targetClass) {
	        StringBuilder testCaseBuilder = new StringBuilder();
	        testCaseBuilder.append("import org.junit.Test;\n");
	        testCaseBuilder.append("import org.junit.Assert;\n\n");
	        testCaseBuilder.append("public class ").append(targetClass.getSimpleName()).append("TestCase {\n\n");

	        // Get constructors, fields, and methods for the target class
	        Constructor<?>[] constructors = targetClass.getDeclaredConstructors();
	        Field[] fields = targetClass.getDeclaredFields();
	        Method[] methods = targetClass.getDeclaredMethods();

	        // Generating test case for each constructor
	        for (Constructor<?> constructor : constructors) {
	            testCaseBuilder.append("@Test\n");
	            testCaseBuilder.append("public void test").append(constructor.getName()).append("() {\n");
	            testCaseBuilder.append("    // Arrange\n");
	            testCaseBuilder.append("    // Act\n");
	            testCaseBuilder.append("    ").append(targetClass.getSimpleName()).append(" instance = new ").append(targetClass.getSimpleName()).append("(/* constructor parameters */);\n");
	            testCaseBuilder.append("    // Assert\n");
	            testCaseBuilder.append("    Assert.assertNotNull(instance);\n");
	            testCaseBuilder.append("}\n\n");
	        }

	        // Generating test case for each field
	        for (Field field : fields) {
	            testCaseBuilder.append("@Test\n");
	            testCaseBuilder.append("public void test").append(field.getName()).append("() {\n");
	            testCaseBuilder.append("    // Arrange\n");
	            testCaseBuilder.append("    // Act\n");
	            testCaseBuilder.append("    ").append(targetClass.getSimpleName()).append(" instance = new ").append(targetClass.getSimpleName()).append("(/* constructor parameters */);\n");
	            testCaseBuilder.append("    // Assert\n");
	            testCaseBuilder.append("    Assert.assertEquals(/* expected value */, instance.").append(field.getName()).append(");\n");
	            testCaseBuilder.append("}\n\n");
	        }

	        // Generate test case for each method
	        for (Method method : methods) {
	            testCaseBuilder.append("@Test\n");
	            testCaseBuilder.append("public void test").append(method.getName()).append("() {\n");
	            testCaseBuilder.append("    // Arrange\n");
	            testCaseBuilder.append("    // Act\n");
	            testCaseBuilder.append("    ").append(targetClass.getSimpleName()).append(" instance = new ").append(targetClass.getSimpleName()).append("(/* constructor parameters */);\n");
	            testCaseBuilder.append("    // Assert\n");
	            testCaseBuilder.append("    Assert.assertEquals(/* expected value */, instance.").append(method.getName()).append("(/* method parameters */));\n");
	            testCaseBuilder.append("}\n\n");
	        }

	        testCaseBuilder.append("}\n");

	        // Save the test case file
	        String outputFilePath = OUTPUT_DIRECTORY + File.separator + targetClass.getSimpleName() + "TestCase.java";
	        try (PrintWriter writer = new PrintWriter(outputFilePath)) {
	            writer.write(testCaseBuilder.toString());
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        }
	    }
}
